#include <stdio.h>
#include <unistd.h>

//********HEAD FIRST C********PAGE 150******ORDER PIZZA
//if we want to capture CLI input
//int main(int argc, char *argv[]){
int main(argc, *argv[]){
	
	char *delivery = "";
	int thick = 0;
	int count = 0;
	char ch;

	while ((ch = getopt(argc, argv, "dt"



	return 0;

}
