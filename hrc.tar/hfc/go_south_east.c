#include <stdio.h>

void go_south_east(int lat, int lon){

	lat = lat - 1;
	lon = lon + 1;

}

