/* Card Evaluation program
 * by Sanjin Zoric
 */

#include <stdio.h>
#include <stdlib.h>



int main() {
	int a = 100;
	int b = 101;
	int *p;
	printf("address of a = %p\n", &a);
	printf("address of b = %p\n", &b);











}
