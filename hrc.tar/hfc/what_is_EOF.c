#include <stdio.h>

//if we want to capture CLI input
//int main(int argc, char *argv[]){
int main(){

	printf("The value of EOF is %i\n", EOF);
	printf("The value of EOF is %i\n", EOL);




	return 0;

}
